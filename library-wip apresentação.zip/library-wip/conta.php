<?php

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <title>Biblioteca TSI</title>
    
    <?php require_once './require/head_links.php';?>

</head>

<body>

    <?php require_once './require/header.php';?>


    <main class="container my-5">

    </main>

    <?php require_once './require/footer.php';?>

</body>

</html>